package programming_oops.db;


import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    static Connection con;

    public static Connection createConnection(){
        try{
           Class.forName("com.mysql.jdbc.Driver");
           String user="root";
           String pass="Hari@2005";
           String url = "jdbc:mysql://localhost:3306/student_db?autoReconnect=true&useSSL=false";


           con= DriverManager.getConnection(url,user,pass);

        }

        catch(Exception ex){
            ex.printStackTrace();
        }


        return con;
    }
}
